# FS-ASM v6.0 – File System as State Machine (Deep Finalization)

**Status:** In active development (modular structure complete, core content migrated and enhanced)  
**Version:** 6.0 (Major structural + evolutionary release)  
**Philosophy:** Externalize all state, rules, and decisions to the file system for maximum determinism, auditability, and reliability.

---

## Quick Start

1. Read `00_Introduction_and_Philosophy.md` for the core doctrine and execution directive.
2. Use the **Bootstrap Protocol** in folder `03_Bootstrap_Protocol/` when starting a new project.
3. Follow the **Task Register Design** rules in `02_State_Register_and_Task_System/`.
4. Apply the recommended patterns from `05_Examples_and_Patterns/` for common task types.
5. Use the **Migration Guide** (`06.2_Migration_Guide_v5.1_to_v6.0.md`) if you are coming from v5.1.

---

## Folder Structure

```
FS-ASM_v6.0/
├── README.md                              ← You are here
├── 00_Introduction_and_Philosophy.md
├── 01_Control_Plane/                      ← INSTRUCTIONS, STANDARDS, etc.
├── 02_State_Register_and_Task_System/     ← How to design todo registers
├── 03_Bootstrap_Protocol/                 ← Full bootstrap process + Quality Gate
├── 04_Execution_Model/                    ← OODA + Error Recovery (with Controlled Dynamics)
├── 05_Examples_and_Patterns/              ← Ready-to-use templates for common scenarios
└── 06_Versioning_and_Evolution/           ← Changelog + Migration Guide
```

---

## Key New Features in v6.0

- **Modular Documentation** — Much easier to navigate and maintain than the monolithic v5.1 document.
- **Controlled Dynamics** — Limited, fully logged retry mechanisms for `[PHYSICS-CRITICAL]` tasks (see 04.2).
- **Improved Task Patterns** — Professional templates for `[PHYSICS-CRITICAL]` and `[DATA-GAP]` tasks.
- **Stronger Emphasis on Input Quality** — The Quality Gate is now more prominently positioned as the first mandatory step.
- **Better Examples** — Concrete, copy-paste ready patterns instead of abstract descriptions.

---

## Compatibility

- Fully backward compatible with v5.1 in terms of runtime behavior and Hard Constraints.
- Existing projects can adopt v6.0 incrementally.
- See `06.2_Migration_Guide_v5.1_to_v6.0.md` for detailed migration steps.

---

## How to Use This Documentation

- **Planning Agent**: Follow `03_Bootstrap_Protocol/` strictly. Use the templates in `05_Examples_and_Patterns/`.
- **Coding Agent**: Read the active task register + relevant Control Plane files. Follow Protocol Zero and OODA.
- **Human Supervisor**: Use this structure for reviews, audits, and onboarding new team members.

---

## Next Steps in Development

- Further expansion of examples
- Additional patterns (e.g., multi-agent coordination within FS-ASM rules)
- Tooling improvements for the `fs-asm-planning-agent` skill
- Community feedback integration

---

**FS-ASM v6.0 represents the most mature, maintainable, and practical version of the methodology to date.**

For questions or contributions, refer to the original specification or open an issue in the project repository.

---

*This README was generated as part of the v6.0 deep finalization process.*