# Minimal matplotlib shim for tests
from . import pyplot
__all__ = ["pyplot"]
