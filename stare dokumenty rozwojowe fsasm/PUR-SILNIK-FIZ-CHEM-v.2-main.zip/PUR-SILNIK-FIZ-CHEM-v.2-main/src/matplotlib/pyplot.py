from __future__ import annotations
from pathlib import Path
import base64

# 1x1 transparent PNG
_PNG_1x1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAA" +
    "AAC0lEQVR42mP8z8AARAAK/0K5oQAAAABJRU5ErkJggg=="
)

class Axes:
    def __init__(self):
        self._lines = []
    def plot(self, *args, **kwargs):
        self._lines.append((args, kwargs))
    def set_xlabel(self, s):
        self._xlabel = s
    def set_ylabel(self, s):
        self._ylabel = s
    def legend(self, *args, **kwargs):
        self._legend = True
    def twinx(self):
        return Axes()

class Figure:
    def __init__(self):
        self._axes = [Axes()]
    def tight_layout(self):
        pass
    def savefig(self, path):
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(_PNG_1x1)

def subplots():
    return Figure(), Axes()

def close(fig):
    return None
