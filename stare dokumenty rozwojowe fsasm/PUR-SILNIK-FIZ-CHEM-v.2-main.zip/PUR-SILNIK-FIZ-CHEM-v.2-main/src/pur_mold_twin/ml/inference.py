from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

try:
    import joblib  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    joblib = None

from .policy import (
    MLArtifactError,
    MLDependencyError,
    MLPolicyError,
    MLStatus,
    MLStatusCode,
    apply_status,
    unexpected_error_status,
)


@dataclass
class LoadedModels:
    defect_risk: Optional[object]
    defect_classifier: Optional[object]


_CACHED_MODELS: Optional[LoadedModels] = None


def _load_models(models_dir: Path = Path("models")) -> LoadedModels:
    global _CACHED_MODELS
    if _CACHED_MODELS is not None:
        return _CACHED_MODELS
    if joblib is None:
        raise MLDependencyError(["joblib"], "Ladowanie modeli ML")

    risk_path = models_dir / "defect_risk.pkl"
    cls_path = models_dir / "defect_classifier.pkl"
    if not risk_path.exists() and not cls_path.exists():
        raise MLArtifactError(models_dir)

    try:
        risk_model = joblib.load(risk_path) if risk_path.exists() else None
        cls_model = joblib.load(cls_path) if cls_path.exists() else None
    except Exception as exc:  # pragma: no cover - joblib errors are rare
        raise MLPolicyError(f"Nie udalo sie wczytac modeli ML: {exc}") from exc

    _CACHED_MODELS = LoadedModels(defect_risk=risk_model, defect_classifier=cls_model)
    return _CACHED_MODELS


def _load_manifest(models_dir: Path = Path("models")) -> Dict[str, Any]:
    """Load optional manifest (JSON) describing model metadata/versioning.

    Expected structure (example):
    {
      "defect_risk": {"version": "1.0.2", "created": "2025-12-01T12:00:00Z"},
      "defect_classifier": {"version": "0.9.0", "created": "2025-11-20T08:00:00Z"}
    }
    """
    manifest_path = models_dir / "manifest.json"
    if not manifest_path.exists():
        return {}
    try:
        import json

        with manifest_path.open("r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {}


def attach_ml_predictions(sim_result: Dict[str, Any], features_row: Dict[str, Any]) -> Dict[str, Any]:
    """Attach ML predictions (if models are available) and annotate status."""

    models_dir = Path("models")
    try:
        global _CACHED_MODELS
        _CACHED_MODELS = None
        models = _load_models(models_dir)
    except MLPolicyError as exc:
        _attach_metadata(sim_result, models_dir)
        return apply_status(sim_result, exc.to_status())
    except Exception as exc:  # pragma: no cover - unexpected edge cases
        _attach_metadata(sim_result, models_dir)
        return apply_status(sim_result, unexpected_error_status(exc))

    from pandas import DataFrame
    from hashlib import sha256

    def _meta_for(path: Path) -> Dict[str, Any]:
        info: Dict[str, Any] = {"path": str(path), "exists": path.exists()}
        if not path.exists():
            return info
        try:
            st = path.stat()
            info.update({"mtime": int(st.st_mtime), "size": int(st.st_size)})
            # compute lightweight sha256 fingerprint
            h = sha256()
            with path.open("rb") as fh:
                for chunk in iter(lambda: fh.read(8192), b""):
                    h.update(chunk)
            info["sha256"] = h.hexdigest()
        except Exception:
            # best-effort only
            pass
        return info

    X = DataFrame([features_row]).drop(columns=["defect_risk", "any_defect"], errors="ignore")

    if models.defect_risk is not None:
        try:
            risk_pred = float(models.defect_risk.predict(X)[0])
            sim_result["defect_risk_pred"] = risk_pred
        except Exception:
            pass

    if models.defect_classifier is not None:
        try:
            cls_pred = models.defect_classifier.predict(X)[0]
            sim_result["defect_class_pred"] = cls_pred
        except Exception:
            pass

    _attach_metadata(sim_result, models_dir)
    return apply_status(sim_result, MLStatus(MLStatusCode.OK, "ML predictions dolaczone"))


def _attach_metadata(sim_result: Dict[str, Any], models_dir: Path) -> None:
    def _meta_for(path: Path) -> Dict[str, Any]:
        info: Dict[str, Any] = {"path": str(path), "exists": path.exists()}
        if not path.exists():
            return info
        try:
            st = path.stat()
            info.update({"mtime": int(st.st_mtime), "size": int(st.st_size)})
            from hashlib import sha256

            h = sha256()
            with path.open("rb") as fh:
                for chunk in iter(lambda: fh.read(8192), b""):
                    h.update(chunk)
            info["sha256"] = h.hexdigest()
        except Exception:
            pass
        return info

    try:
        sim_result.setdefault("ml_models", {})
        sim_result["ml_models"]["defect_risk"] = _meta_for(models_dir / "defect_risk.pkl")
        sim_result["ml_models"]["defect_classifier"] = _meta_for(models_dir / "defect_classifier.pkl")
        manifest = _load_manifest(models_dir)
        if manifest:
            for key, meta in manifest.items():
                try:
                    if not isinstance(meta, dict) or "version" not in meta:
                        sim_result["ml_models"].setdefault(key, {}).setdefault("manifest", {})["_invalid"] = True
                        continue
                    dest = sim_result["ml_models"].setdefault(key, {})
                    dest_manifest = dest.setdefault("manifest", {})
                    for fld in ("version", "created", "git_sha", "requirements_hash", "sha256"):
                        if fld in meta:
                            dest_manifest[fld] = meta[fld]
                    expected_sha = meta.get("sha256")
                    if expected_sha:
                        model_pkl = models_dir / f"{key}.pkl"
                        actual_info = _meta_for(model_pkl)
                        actual_sha = actual_info.get("sha256")
                        dest_manifest["sha256_match"] = (actual_sha == expected_sha)
                        dest_manifest["sha256_actual"] = actual_sha
                except Exception:
                    pass
    except Exception:
        pass

