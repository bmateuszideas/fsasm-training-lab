"""Common ML error handling policy helpers."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Iterable, Mapping


class MLStatusCode(str, Enum):
    """Canonical status codes surfaced by CLI/API/ML helpers."""

    OK = "ok"
    MISSING_EXTRAS = "missing-ml-extras"
    MISSING_MODELS = "missing-ml-models"
    INVALID_INPUT = "invalid-ml-input"
    INTERNAL_ERROR = "ml-error"


@dataclass
class MLStatus:
    """Structured status descriptor attached to payloads."""

    code: MLStatusCode
    detail: str | None = None

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {"code": self.code.value}
        if self.detail:
            data["detail"] = self.detail
        return data


class MLPolicyError(RuntimeError):
    """Base exception carrying an ML status code for downstream handling."""

    status_code: MLStatusCode = MLStatusCode.INTERNAL_ERROR

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self._detail = message

    def to_status(self) -> MLStatus:
        return MLStatus(self.status_code, self._detail)


class MLDependencyError(MLPolicyError):
    status_code = MLStatusCode.MISSING_EXTRAS

    def __init__(self, missing: Iterable[str], action: str) -> None:
        required = ", ".join(sorted(missing))
        detail = (
            f"{action} wymaga extras ML ({required}). "
            "Uruchom `pip install .[ml]` albo sprawdz docs/ML_LOGGING.md."
        )
        super().__init__(detail)


class MLArtifactError(MLPolicyError):
    status_code = MLStatusCode.MISSING_MODELS

    def __init__(self, models_dir: Path) -> None:
        super().__init__(
            f"Brak modelow ML w '{models_dir}'. Uruchom `pur-mold-twin train-ml` albo wskaz katalog z artifactami."
        )


class MLInputError(MLPolicyError):
    status_code = MLStatusCode.INVALID_INPUT


def ensure_dependencies(dependencies: Mapping[str, object | None], *, action: str) -> None:
    """Raise a consistent error when optional ML dependencies are missing."""

    missing = [name for name, handle in dependencies.items() if handle is None]
    if missing:
        raise MLDependencyError(missing, action)


def apply_status(payload: dict[str, Any], status: MLStatus) -> dict[str, Any]:
    """Attach an ML status to the given payload in-place."""

    payload["ml_status"] = status.to_dict()
    return payload


def unexpected_error_status(exc: Exception) -> MLStatus:
    """Build a human-readable fallback status for uncaught exceptions."""

    return MLStatus(MLStatusCode.INTERNAL_ERROR, f"{exc.__class__.__name__}: {exc}")
