"""
Training entry point for baseline ML models (optional extras).

Usage (script):
    python -m pur_mold_twin.ml.train_baseline --features data/ml/features.parquet

Usage (CLI):
    pur-mold-twin train-ml --features data/ml/features.parquet
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Tuple

try:
    import pandas as pd  # type: ignore
    from sklearn.metrics import f1_score, mean_absolute_error  # type: ignore
    import joblib  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    pd = None
    mean_absolute_error = None
    f1_score = None
    joblib = None

from .baseline import BaselineModels, build_baseline_models
from .policy import MLInputError, MLPolicyError, ensure_dependencies
import hashlib
from datetime import datetime, timezone
import subprocess
import random
from typing import Optional


@dataclass
class TrainingReport:
    samples: int
    features: int
    mae_defect_risk: float | None
    f1_any_defect: float | None


def _train_models(df: "pd.DataFrame") -> Tuple[BaselineModels, TrainingReport]:
    models = build_baseline_models()

    mae_value: float | None = None
    f1_value: float | None = None

    X = df.drop(columns=["defect_risk", "any_defect"], errors="ignore")

    if "defect_risk" in df.columns and mean_absolute_error is not None:
        y_risk = df["defect_risk"]
        models.defect_risk_regressor.fit(X, y_risk)
        preds = models.defect_risk_regressor.predict(X)
        mae_value = float(mean_absolute_error(y_risk, preds))

    if "any_defect" in df.columns and f1_score is not None:
        y_cls = df["any_defect"]
        models.defect_classifier.fit(X, y_cls)
        preds_cls = models.defect_classifier.predict(X)
        f1_value = float(f1_score(y_cls, preds_cls))

    report = TrainingReport(
        samples=int(len(df)),
        features=int(X.shape[1]),
        mae_defect_risk=mae_value,
        f1_any_defect=f1_value,
    )
    return models, report


def _save_models(models: BaselineModels, out_dir: Path, model_version: Optional[str] = None, training_seed: Optional[int] = None, dataset_fingerprint: Optional[str] = None) -> Dict[str, str]:
    if joblib is None:
        raise ImportError("joblib is required to save ML models; install with pur-mold-twin[ml]")

    out_dir.mkdir(parents=True, exist_ok=True)
    paths: Dict[str, str] = {}
    if models.defect_risk_regressor is not None:
        path = out_dir / "defect_risk.pkl"
        joblib.dump(models.defect_risk_regressor, path)
        paths["defect_risk"] = str(path)
    if models.defect_classifier is not None:
        path = out_dir / "defect_classifier.pkl"
        joblib.dump(models.defect_classifier, path)
        paths["defect_classifier"] = str(path)
    # write manifest with metadata and model fingerprints
    try:
        manifest = {}
        # compute project requirements hash (best-effort: pyproject.toml)
        req_hash = None
        proj_file = Path("pyproject.toml")
        if proj_file.exists():
            h = hashlib.sha256()
            h.update(proj_file.read_bytes())
            req_hash = h.hexdigest()

        # git sha (best effort)
        git_sha = None
        try:
            git_sha = subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], stderr=subprocess.DEVNULL).decode().strip()
        except Exception:
            git_sha = None

        for name, p in paths.items():
            ppath = Path(p)
            m: Dict[str, str] = {"version": model_version or "0.0.0", "created": datetime.now(timezone.utc).isoformat()}
            if git_sha:
                m["git_sha"] = git_sha
            if req_hash:
                m["requirements_hash"] = req_hash
            if training_seed is not None:
                m["training_seed"] = int(training_seed)
            if dataset_fingerprint is not None:
                m["dataset_fingerprint"] = dataset_fingerprint
            # compute sha256 of model file
            try:
                hh = hashlib.sha256()
                with ppath.open("rb") as fh:
                    for chunk in iter(lambda: fh.read(8192), b""):
                        hh.update(chunk)
                m["sha256"] = hh.hexdigest()
            except Exception:
                pass
            manifest[name] = m
        # write manifest.json alongside models
        (out_dir / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    except Exception:
        # best-effort only
        pass
    return paths


def _write_metrics_report(report: TrainingReport, model_paths: Dict[str, str], output_path: Path) -> Path:
    lines = ["# ML Baseline Training Report", ""]
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- samples: {report.samples}")
    lines.append(f"- features: {report.features}")
    if report.mae_defect_risk is not None:
        lines.append(f"- MAE defect_risk: {report.mae_defect_risk:.4f}")
    if report.f1_any_defect is not None:
        lines.append(f"- F1 any_defect: {report.f1_any_defect:.4f}")
    lines.append("")
    lines.append("## Model artifacts")
    lines.append("")
    for name, path in model_paths.items():
        lines.append(f"- **{name}**: `{path}`")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(lines), encoding="utf-8")
    return output_path


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Train baseline ML models.")
    parser.add_argument("--features", required=True, type=Path, help="Path to features parquet/CSV file.")
    parser.add_argument("--models-dir", type=Path, default=Path("models"), help="Directory for saved models.")
    parser.add_argument("--model-version", type=str, default=None, help="Optional model version string to write to manifest.")
    parser.add_argument("--seed", type=int, default=None, help="Optional random seed for training reproducibility.")
    parser.add_argument("--metrics-path", type=Path, default=Path("reports/ml/metrics.md"), help="Metrics report path.")
    args = parser.parse_args(argv)

    ensure_dependencies(
        {
            "pandas": pd,
            "scikit-learn": mean_absolute_error,
            "joblib": joblib,
        },
        action="Trening modeli baseline",
    )

    if not args.features.exists():
        raise FileNotFoundError(f"Features file '{args.features}' not found")

    try:
        if args.features.suffix.lower() == ".csv":
            df = pd.read_csv(args.features)
        else:
            df = pd.read_parquet(args.features)
    except Exception as exc:
        raise MLInputError(f"Nie udalo sie wczytac danych z '{args.features}': {exc}") from exc

    if df.empty:
        raise MLInputError(f"Plik '{args.features}' nie zawiera zadnych wierszy do treningu.")

    # dataset fingerprint (sha256 of the features file) - deterministic reproducibility aid
    dataset_fingerprint = None
    try:
        h = hashlib.sha256()
        h.update(args.features.read_bytes())
        dataset_fingerprint = h.hexdigest()
    except Exception:
        dataset_fingerprint = None

    # control randomness if seed provided
    if args.seed is not None:
        try:
            random.seed(int(args.seed))
            import numpy as _np  # type: ignore

            _np.random.seed(int(args.seed))
        except Exception:
            pass

    models, report = _train_models(df)
    model_paths = _save_models(models, args.models_dir, model_version=args.model_version, training_seed=args.seed, dataset_fingerprint=dataset_fingerprint)
    _write_metrics_report(report, model_paths, args.metrics_path)

    # Simple JSON payload on stdout for CLI usage / tests
    payload: Dict[str, Any] = {
        "report": asdict(report),
        "models": model_paths,
    }
    print(json.dumps(payload))


if __name__ == "__main__":  # pragma: no cover
    try:
        main()
    except MLPolicyError as exc:  # pragma: no cover
        import sys

        sys.stderr.write(f"[ML] {exc}\n")
        raise SystemExit(1)
