from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import logging
import json
import time
import uuid
from typing import List, Union

from .api import APIService

# Try to use pydantic-settings (for pydantic v2); if not present, fall back
# to a tiny env-based loader so the service imports cleanly in minimal envs.
try:
    from pydantic_settings import BaseSettings  # type: ignore

    class Settings(BaseSettings):
        service_title: str = "PUR Mold Twin Service"
        service_version: str = "0.1.0"
        allow_origins: Union[List[str], str] = "*"
        allow_methods: List[str] = ["GET", "POST", "OPTIONS"]
        allow_headers: List[str] = ["*"]
        log_level: str = "INFO"
        enable_request_logging: bool = True

        class Config:
            env_prefix = "PUR_MT_"

    settings = Settings()
except Exception:
    import os

    class Settings:
        def __init__(self) -> None:
            self.service_title = os.getenv("PUR_MT_SERVICE_TITLE", "PUR Mold Twin Service")
            self.service_version = os.getenv("PUR_MT_SERVICE_VERSION", "0.1.0")
            self.allow_origins = os.getenv("PUR_MT_ALLOW_ORIGINS", "*")
            self.allow_methods = ["GET", "POST", "OPTIONS"]
            self.allow_headers = ["*"]
            self.log_level = os.getenv("PUR_MT_LOG_LEVEL", "INFO")
            self.enable_request_logging = os.getenv("PUR_MT_ENABLE_REQUEST_LOGGING", "1") in (
                "1",
                "true",
                "True",
                "yes",
            )

    settings = Settings()


logger = logging.getLogger("pur_mold_twin.service")
app = FastAPI(title=settings.service_title, version=settings.service_version)


def _normalize_origins(value: Union[List[str], str]) -> List[str]:
    if isinstance(value, list):
        return value
    if not value:
        return []
    return [s.strip() for s in str(value).split(",") if s.strip()]


app.add_middleware(
    CORSMiddleware,
    allow_origins=_normalize_origins(settings.allow_origins),
    allow_methods=settings.allow_methods,
    allow_headers=settings.allow_headers,
)

service = APIService()


from contextlib import asynccontextmanager


@asynccontextmanager
async def lifespan(app: FastAPI):
    # startup
    level = getattr(logging, settings.log_level.upper(), logging.INFO)
    logging.basicConfig(level=level)
    logger.setLevel(level)
    yield
    # shutdown (no-op)


app.router.lifespan_context = lifespan


@app.middleware("http")
async def _log_requests(request: Request, call_next):
    request_id = str(uuid.uuid4())
    start = time.time()
    request.state.request_id = request_id
    if settings.enable_request_logging:
        logger.info(json.dumps({"event": "request_start", "id": request_id, "method": request.method, "path": request.url.path}))
    resp = await call_next(request)
    duration = time.time() - start
    if settings.enable_request_logging:
        logger.info(json.dumps({"event": "request_end", "id": request_id, "method": request.method, "path": request.url.path, "status": resp.status_code, "duration_s": round(duration, 4)}))
    resp.headers["X-Request-Id"] = request_id
    return resp


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/ready")
def ready():
    # simple readiness: service constructed and APIService present
    ok = True
    try:
        _ = service is not None
    except Exception:
        ok = False
    return {"ready": ok}


@app.get("/metrics")
def metrics():
    # lightweight metrics placeholder: expose simple process info
    return {"service": settings.service_title, "version": settings.service_version}


@app.post("/ml/predict")
async def ml_predict(request: Request):
    payload = await request.json()
    try:
        out = service.ml_predict(payload)
        return out
    except Exception as exc:  # pragma: no cover - best-effort service
        logger.exception("ml_predict failed")
        return {"error": str(exc)}


@app.post("/simulate")
async def simulate(request: Request):
    payload = await request.json()
    try:
        out = service.simulate(payload)
        return out
    except Exception as exc:  # pragma: no cover
        logger.exception("simulate failed")
        return {"error": str(exc)}
