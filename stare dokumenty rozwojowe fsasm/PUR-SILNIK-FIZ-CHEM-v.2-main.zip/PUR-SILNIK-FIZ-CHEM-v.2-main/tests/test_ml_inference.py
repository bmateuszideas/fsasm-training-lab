import json
from pathlib import Path

from src.pur_mold_twin.ml.inference import attach_ml_predictions
from src.pur_mold_twin.ml.policy import MLStatusCode


def test_attach_metadata_with_manifest(tmp_path):
    # prepare a models dir with manifest and empty model files
    models_dir = tmp_path / "models"
    models_dir.mkdir()
    (models_dir / "defect_risk.pkl").write_bytes(b"")
    (models_dir / "defect_classifier.pkl").write_bytes(b"")
    manifest = {
        "defect_risk": {"version": "1.2.3", "created": "2025-12-01T12:00:00Z"},
        "defect_classifier": {"version": "0.9.0", "created": "2025-11-20T08:00:00Z"},
    }
    with (models_dir / "manifest.json").open("w", encoding="utf-8") as fh:
        json.dump(manifest, fh)

    # call attach_ml_predictions pointing to that models dir
    sim = {}
    features = {"some_feature": 1}

    # monkeypatch default models path by changing cwd temporarily
    cwd = Path.cwd()
    try:
        import os

        os.chdir(tmp_path)
        out = attach_ml_predictions(sim, features)
    finally:
        os.chdir(cwd)

    assert "ml_models" in out
    assert "defect_risk" in out["ml_models"]
    assert "defect_classifier" in out["ml_models"]
    assert out["ml_models"]["defect_risk"]["exists"] is True
    assert out["ml_models"]["defect_risk"]["manifest"]["version"] == "1.2.3"
    assert "ml_status" in out
    assert out["ml_status"]["code"] in {
        MLStatusCode.OK.value,
        MLStatusCode.MISSING_EXTRAS.value,
        MLStatusCode.INTERNAL_ERROR.value,
    }