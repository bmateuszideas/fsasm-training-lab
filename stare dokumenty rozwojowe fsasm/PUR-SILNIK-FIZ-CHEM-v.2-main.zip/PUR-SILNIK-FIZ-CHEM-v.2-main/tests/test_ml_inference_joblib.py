import os
import pickle
import types
from pathlib import Path

from src.pur_mold_twin.ml import inference
from src.pur_mold_twin.ml.inference import attach_ml_predictions
from src.pur_mold_twin.ml.policy import MLStatusCode
from src.pur_mold_twin.service.api import APIService


class DummyRisk:
    def predict(self, X):
        return [0.424242]


def test_attach_predictions_with_joblib_and_service(tmp_path, monkeypatch):
    # prepare models dir
    models_dir = tmp_path / "models"
    models_dir.mkdir()
    # create pickled dummy predictor
    (models_dir / "defect_risk.pkl").write_bytes(pickle.dumps(DummyRisk()))

    # monkeypatch inference.joblib to a simple shim that uses pickle
    monkeypatch.setattr(inference, "joblib", types.SimpleNamespace(load=lambda p: pickle.load(open(p, "rb"))))

    # run attach_ml_predictions with cwd pointing to tmp_path so models/ is discovered
    cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        out = attach_ml_predictions({}, {"feature_x": 1})
    finally:
        os.chdir(cwd)

    assert "defect_risk_pred" in out
    assert abs(out["defect_risk_pred"] - 0.424242) < 1e-9
    assert out["ml_status"]["code"] == MLStatusCode.OK.value

    # Also check APIService.ml_predict integration
    svc = APIService()
    try:
        os.chdir(tmp_path)
        svc_out = svc.ml_predict({"feature_x": 1})
    finally:
        os.chdir(cwd)
    assert "defect_risk_pred" in svc_out
    assert svc_out["ml_status"]["code"] == MLStatusCode.OK.value