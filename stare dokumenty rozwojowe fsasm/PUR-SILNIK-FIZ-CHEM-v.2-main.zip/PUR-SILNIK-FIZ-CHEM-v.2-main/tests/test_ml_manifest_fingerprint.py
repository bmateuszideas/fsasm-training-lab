import json
import hashlib
import os
from pathlib import Path

from src.pur_mold_twin.ml.inference import attach_ml_predictions


def sha256_hex(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def test_manifest_fingerprint_match(tmp_path):
    models_dir = tmp_path / "models"
    models_dir.mkdir()
    f = models_dir / "defect_risk.pkl"
    f.write_bytes(b"dummy content for fingerprint")
    expected = sha256_hex(f)
    manifest = {"defect_risk": {"version": "1.0.0", "sha256": expected}}
    (models_dir / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")

    cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        out = attach_ml_predictions({}, {"feature": 1})
    finally:
        os.chdir(cwd)

    assert "ml_models" in out
    dr = out["ml_models"]["defect_risk"]
    assert dr["exists"] is True
    assert dr["manifest"]["sha256_match"] is True
    assert dr["manifest"]["sha256_actual"] == expected


def test_manifest_fingerprint_mismatch(tmp_path):
    models_dir = tmp_path / "models"
    models_dir.mkdir()
    f = models_dir / "defect_risk.pkl"
    f.write_bytes(b"some other content")
    expected = "deadbeef" * 8
    manifest = {"defect_risk": {"version": "1.0.0", "sha256": expected}}
    (models_dir / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")

    cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        out = attach_ml_predictions({}, {"feature": 1})
    finally:
        os.chdir(cwd)

    dr = out["ml_models"]["defect_risk"]
    assert dr["exists"] is True
    assert dr["manifest"]["sha256_match"] is False