from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "ml_status_tester.py"


def _run(case: str) -> tuple[int, dict]:
    proc = subprocess.run(
        [sys.executable, str(SCRIPT), "--case", case],
        capture_output=True,
        text=True,
        cwd=ROOT,
    )
    stdout = proc.stdout.strip()
    if not stdout:
        return proc.returncode, {}
    try:
        data = json.loads(stdout)
    except json.JSONDecodeError:
        pytest.fail(f"Tester emitted invalid JSON: {stdout}")
    return proc.returncode, data


def test_ok_case_reports_success():
    code, payload = _run("ok")
    status = payload.get("result", {}).get("ml_status", {}).get("code")
    if code != 0 and payload.get("ml_status", {}).get("code") == "missing-ml-extras":
        pytest.skip("ML extras are not installed")
    assert code == 0
    assert status == "ok"


def test_missing_models_case():
    code, payload = _run("missing-models")
    assert code == 0
    status = payload["result"]["ml_status"]["code"]
    assert status == "missing-ml-models"


def test_missing_extras_case():
    code, payload = _run("missing-extras")
    assert code == 0
    status = payload["result"]["ml_status"]["code"]
    assert status == "missing-ml-extras"
