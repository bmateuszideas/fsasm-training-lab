import os
import pickle
from pathlib import Path

import pytest

try:
    from fastapi.testclient import TestClient
    from src.pur_mold_twin.service.app import app
except Exception:  # pragma: no cover - skip when fastapi not installed
    TestClient = None
    app = None

from src.pur_mold_twin.ml import inference


class DummyRisk:
    def predict(self, X):
        return [0.123456]


@pytest.mark.skipif(TestClient is None, reason="fastapi not installed")
def test_service_ml_predict_endpoint(tmp_path, monkeypatch):
    # prepare models dir and pickled predictor
    models_dir = tmp_path / "models"
    models_dir.mkdir()
    (models_dir / "defect_risk.pkl").write_bytes(pickle.dumps(DummyRisk()))

    # monkeypatch inference.joblib to use pickle loader
    monkeypatch.setattr(inference, "joblib", type("J", (), {"load": staticmethod(lambda p: pickle.load(open(p, "rb")))}))

    cwd = Path.cwd()
    try:
        os.chdir(tmp_path)
        client = TestClient(app)
        resp = client.post("/ml/predict", json={"feature_x": 1})
    finally:
        os.chdir(cwd)

    assert resp.status_code == 200
    body = resp.json()
    assert "defect_risk_pred" in body
    assert abs(body["defect_risk_pred"] - 0.123456) < 1e-9
