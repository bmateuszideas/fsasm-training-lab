# TODO4 – Faza przygotowania do releasu 1.0.0

Ten dokument jest kontynuacja `todo3.md`. Traktuj go jako scenariusz A→Z dla kolejnego mechanika/ developera, ktory przejmuje gotowy projekt i ma domknac finalne prace przed wersja 1.0.0.

## 0. TL;DR (co trzeba zrobic)


**STATUS: Sekcja 0 (TL;DR) została w pełni wykonana. Wszystkie punkty od 1 do 5 są odhaczone i potwierdzone w repozytorium. Przed kolejnymi krokami zawsze czytaj README oraz pliki referencyjne (`docs/ML_LOGGING.md`, `README_VERS.md`, `DEV_DASHBOARD_TODO3.md`, changelogi, testy).**

## 1. Kontekst projektu (stan na 2025-12-03)


**STATUS: Paragraf 1 (Kontekst projektu) został w pełni wykonany i potwierdzony. Rdzeń symulatora 0D/1D, polityka ML, aktywne skrypty, workflow CI/release oraz testy regresyjne są zgodne z checklistą i stanem repozytorium.**

## 2. Procedura A→Z


**STATUS: Paragraf 2 (Procedura A→Z) został w pełni wykonany i potwierdzony. Wszystkie kroki setup, testy bazowe, tester ML, lint oraz release checklist zostały zrealizowane zgodnie z instrukcją. Repozytorium jest gotowe do releasu 1.0.0.**

## 3. Workstreams TODO4

| ID | Obszar | Status | Notatki |
|----|--------|--------|---------|
| 4.1 | Dokumentacja | ✅ Zaktualizowane | README (sekcja „Release prep”) i `docs/ML_LOGGING.md` opisują politykę `ml_status`, tester CLI i checklistę releasu. |
| 4.2 | Tester ML | ✅ Zaktualizowane | `scripts/ml_status_tester.py` + `tests/test_ml_status_tester.py` pokrywaja case `ok/missing-models/missing-extras`; ewentualny GUI to opcjonalny follow-up. |
| 4.3 | CI lint | ✅ Zaktualizowane | `.github/workflows/ci.yml` ma job `lint` (ruff/black/markdownlint-cli2) i zawężoną macierz testową (Py 3.11/3.12/3.14, extras on/off). |
| 4.4 | Release | ✅ Wykonane | Checklist manualny: `pytest -q`, `python scripts/smoke_e2e.py`, wszystkie scenariusze testera ML, update `README_VERS.md`/`todo4.md`, tag `v1.0.0`, obserwacja `release.yml` (potwierdzone w repozytorium 2025-12-04). |

## 4. Guidelines dla kolejnego developera

1. **Nie ruszaj archiwum** – `scripts/archive/` to snapshoty; wszystko co nowe trafia do `scripts/` albo `tests/helpers/`.
2. **ML jest opcjonalny** – kazda integracja (CLI/API) musi dzialac bez `[ml]`. Uzywamy `ml_status` do komunikacji stanu.
3. **Dokumentuj** – zmiany w TODO4 odnotuj w `todo4.md`, `README_VERS.md` i ewentualnie w `DEV_DASHBOARD_TODO3.md` (sekcja „Snapshot CI + skrypty”).
4. **Testy musza byc realne** – brak mockow: generuj pliki tymczasowe w `tmp/`/`tmp_debug_*` (tworz w runtime, nie trzymaj w repo).

## 5. Plan tester CLl

Minimalny zakres `scripts/ml_status_tester.py` (gotowe, uruchamiaj przed releasem):

```text
Usage: python scripts/ml_status_tester.py --case <ok|missing-models|missing-extras>

Case ok:
  - korzysta z prawdziwych modeli (np. generowanych przez tests/helpers/build_ml_models.py)
  - wypisuje JSON z `ml_status = ok`
Case missing-models:
  - ustawia pusty katalog models -> oczekuje statusu `missing-ml-models`
Case missing-extras:
  - uruchamia proces w sub-procesie z `PYTHONPATH=src` i `python -S` bez extras (symulacja)
```

## 6. Załączniki / referencje

- `docs/ML_LOGGING.md` – polityka ML.
- `DEV_DASHBOARD_TODO3.md` – snapshot CI oraz zasady pracy.
- `README_VERS.md` – historia wersji.
- `scripts/service_example.py` – referencja API.
- `tests/test_ml_*` – przyklad realnych testow.

---
Aktualizacja: 2025-12-03, autor: Majster.
